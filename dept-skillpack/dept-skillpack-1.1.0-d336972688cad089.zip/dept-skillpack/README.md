# 项目开发部技能包 v1.1.0

同事只需要三条命令。**不需要 npm install，不需要任何额外依赖**（Node 20+ 即可）。

```bash
cd dept-skillpack
node install.mjs install      # 装
node install.mjs doctor       # 体检：外部依赖 + 三条授权腿
node install.mjs auth         # 缺哪条腿补哪条（已就绪的自动跳过）
```

之后：

```bash
node install.mjs status       # 我旧了吗
node install.mjs upgrade      # 只更新真变了的技能（按内容 sha256 判断）
```

## 这个包里有什么

| 技能 | 管什么 | 必装？ |
| --- | --- | --- |
| `dept-pack-guide` | 导航：该用哪个技能、授权怎么弄 | 是 |
| `quectel-cli` | 统一鉴权入口 + PMS/QPMS/工单/会议查询 | 是 |
| `quectel-pms-query` | 查 QPMS 项目 / 产品 / OC / 审批 / 流程卡在谁 | 是 |
| `qpms-worktime` | 填 / 补 / 提交 QPMS 工时 | 是 |
| `msgraph-delegated-setup` | 个人 Outlook / Microsoft 365 邮箱与日历 | 是 |
| `kimi-webbridge` | 浏览器执行器的一种 | **可选**（agent 自带浏览器工具就不需要） |

## 装到哪

默认 `~/.claude/skills/`，可用 `--dir` 或 `SKILLPACK_SKILLS_ROOT` 改。
对其他 agent（Cursor / Gemini / Codex…）指到它自己的 skills 目录即可。

## 授权

三条腿是**三个独立身份源**，合并不了，但入口只有一个：

- **Quectel SSO**（一条根凭据，覆盖 PMS 查询与工时填报）
- **Microsoft 365**（个人邮箱，与 Quectel 账号无关）
- **飞书**（本包暂无技能直接依赖）

`node install.mjs auth` 按顺序走完，已经就绪的直接跳过。

> 浏览器能力是**探测制**：quectel-cli 的 token 是根凭据，浏览器只是执行器。
> 优先用 agent 自带的浏览器工具，都没有才需要 Kimi WebBridge。
